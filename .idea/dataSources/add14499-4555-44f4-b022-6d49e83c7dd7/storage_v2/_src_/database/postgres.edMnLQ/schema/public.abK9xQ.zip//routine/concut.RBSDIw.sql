create function concut(t orders)
  returns text
language plpgsql
as $$
begin
return t.mfr||t.mfr;
end;
$$;

